package Procesos;

import java.util.ArrayList;

import Procesos.Casilla;

public class Grupo{
    private String color;
    private ArrayList<Casilla> casillas;
    private int tam;

    private int precio; //Precio por casilla

    private Jugador propietario;

    private static final int pBase = 100;
    private int numero; //Color/grupo 0-7.
    /* Tomando ciertas libertades artísticas:
    0 - Marrón
    1 - Cián
    2 - Fucsia
    3 - Tangerina
    4 - Escarlatata
    5 - Amarillo
    6 - Verde
    7 - Azul
     */


    private static final String[] listaInicioFormatoColor = {"\u001B[33m", "\u001B[36m", "\u001B[35m", "\u001B[38;5;208m", "\u001B[31m", "\u001B[33m", "\u001B[32m", "\u001B[34m"};
    //Métodos internos
    private static int powP(int exponente,double multiplicador){ //Cálculo de precios con multiplicador de un grupo a otro
        /*double dpBase = pBase;*/
        return (int) (pBase * Math.pow(multiplicador,exponente));
    }
    private static int powP(int exponente){ //Cálculo de precios con multiplicador 1.3
        /*double dpBase = pBase;*/
        double multiplicador = 1.3;
        return (int) (pBase * Math.pow(multiplicador,exponente));
    }

    private static int[] listaPrecios = {pBase,powP(1),powP(2),powP(3),powP(4),powP(5),powP(6),powP(7)};
//Constructores

    public Grupo(int numero) {
        color = new String[]{"Marrón", "Cián", "Rosa","Naranja","Rojo","Amarillo","Verde","Azul"}[numero];

        this.numero = numero;
        if (numero == 0 || numero == 7) tam = 2;
        else tam = 3;
        casillas = new ArrayList<>(tam);

        precio = listaPrecios[numero];

        propietario = null;
    }

    //Getters
    public ArrayList<Casilla> getCasillas() {
        return casillas;
    }

    public Jugador getPropietario() {
        return propietario;
    }

    public int getPrecio() {
        return precio;
    }

    public int getTam() {
        return tam;
    }

    public int getNumero() {
        return numero;
    }

    public String getColor() {
        return color;
    }

    public String colorFormato(){
        return listaInicioFormatoColor[numero];
    }

//Setters


    public void setCasillas(ArrayList<Casilla> casillas) {
        this.casillas = casillas;
    }

    public void addCasilla (Casilla casilla){
        this.casillas.add(casilla);
    }

    public void setPropietario(Jugador propietario) { //Se llama desde addCasilla en caso de sea la última casilla a comprar en el grupo
        this.propietario = propietario;
    }
    public static int mediaSolares(){
        return (listaPrecios[0]*2+listaPrecios[1]*3+listaPrecios[2]*3+listaPrecios[3]*3+listaPrecios[4]*3+listaPrecios[5]*3+listaPrecios[6]*3+listaPrecios[7]*2)/22;
    }

}
