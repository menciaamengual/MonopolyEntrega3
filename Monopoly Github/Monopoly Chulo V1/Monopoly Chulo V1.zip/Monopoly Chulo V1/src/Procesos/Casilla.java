package Procesos;

import Procesos.Dado;

import java.util.ArrayList;
import Juego.*;

public class Casilla {
    //Atributos
    private int tipo; //0-9. 0.Solar; 1.Transporte; 2.Servicios;
    // 3. Suerte o Caja de comunidad. 4.Cárcel. 5.Parkineos. 6. Impuesto. 7.Salida 8.Ir cárcel
    private int posicion; //0-43
    private String nombre;
    private Jugador propietario; //si tiene
    private boolean hipotecado;
    private int precio; //Tener en cuenta que aumenta 5% cada vuelta no comprado
    private int alquilerBase; //Alquiler base de una casilla
    private int vHipoteca; //Si corresponde
    private Grupo grupo; //Color/grupo
    // Tomando ciertas libertades artísticas:
    //0 - Marrón 1 - Cián 2 - Fucsia 3 - Tangerina 4 - Escarlateta 5 - Amarillo 6 - Verde 7 - Azul
   /* private int nivel; //Lo usamos para calcular el alquiler - EN ESTA ENTREGA, las condiciones son demasiado sencillas como para que tenga sentido usar esto

     * Para solares         0 - 6: 0.propiedad Básica. 1 propiedad en Procesos.Grupo. 2..5 casas (n-1), 6. Un hotel
     * Para transportes     1 - 4: Número de cartas de transporte que posee el propietario
     * Para servicios       1-2: Número de cartas de servicios que posee el jugador
     */
    private ArrayList<Jugador> ocupantes;
    private static int lonMaxNombre = 11; //Longitud del nombre en impresión. Función que mira long del nombre + largo


    public Casilla (int pBase,int pSalida, int posicion, String nombre, ArrayList<Grupo> grupos) {
        Grupo[] ArrayAux_grupo= {null, grupos.get(1-1), null, grupos.get(1-1), null, null, grupos.get(2-1), null, grupos.get(2-1), grupos.get(2-1), null, grupos.get(3-1), null, grupos.get(3-1), grupos.get(3-1), null, grupos.get(4-1), null, grupos.get(4-1), grupos.get(4-1), null, grupos.get(5-1), null, grupos.get(5-1), grupos.get(5-1), null, grupos.get(6-1), grupos.get(6-1), null, grupos.get(6-1), null, grupos.get(7-1), grupos.get(7-1), null, grupos.get(7-1), null, null, grupos.get(8-1), null, grupos.get(8-1)};
        int[] ArrayAux_tipoCasilla = {7, 0, 3, 0, 6, 1, 0, 3, 0, 0, 4, 0, 2, 0, 0, 1, 0, 3, 0, 0, 5, 0, 3, 0, 0, 1, 0, 0, 2, 0, 8, 0, 0, 3, 0, 1, 3, 0, 6, 0};


        ocupantes = new ArrayList<>(6);
        grupo = ArrayAux_grupo[posicion];
        this.tipo = ArrayAux_tipoCasilla[posicion];
        this.posicion = posicion;
        this.nombre = nombre;
        this.alquilerBase = 0;
        this.hipotecado = false;
        this.propietario = null;
        this.precio = 0;

        switch (tipo) {
            case 0: //Solar
                grupo.addCasilla(this);
                precio = grupo.getPrecio();
                alquilerBase =(int)(precio * 0.1);
                break;
            case 1: //Transporte
                precio = pSalida;
                alquilerBase =(int)(0.25*pSalida);
                break;

            case 2: //Servicios
                precio = (int) (pSalida * 0.75);
                alquilerBase =(int)(pSalida/200); //POR EL VALOR DE LOS DADOS
                //factorServicio=200 veces menos que pSalida
                break;

            case 3: //Suerte / Caja Comunidad
                break;

            case 4: // Carcel
                break;

            case 5: // Parking
                alquilerBase = 0; //actualizaremos este valor en función del dinero que se vaya acumulando en impuestos
                break;

            case 6: //Impuesto
                if (posicion<20) alquilerBase = pSalida/2;
                else alquilerBase = pSalida;
                break;

            case 7: //Salida
                break;

            case 8: // Ir Carcel
                break;


        }
        vHipoteca = (int) precio / 2;
    }

    //Setters

    public void removeOcupante(Jugador jugador){
        ocupantes.remove(jugador);
    }
    public void setOcupantes(ArrayList<Jugador> ocupantes) {
        this.ocupantes = ocupantes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    /**
     * Settea el propietario, añadiendo además la casilla a su lista de propiedades
     * Al llamar a addPropiedad, también hace la comprobación de los grupos
     * @param propietario
     */
    public void setPropietario(Jugador propietario){
        if (tipo>2) return; //Si no es un solar, servicio o transporte, no se le puede asignar propietario
        this.propietario = propietario;
        propietario.addPropiedad(this);
    }

    public void setAlquilerBase(int alquilerBase) { //Pensada para trabajar con parking gratuito
        this.alquilerBase = alquilerBase;
    }
    //Getters

    public int getAlquilerBase() {
        return alquilerBase;
    }

    public String getTipoString(){
        String aux = new String[]{"Solar", "Transporte", "Servicios","Suerte/Comunidad","Cárcel","Parking","Impuestos","Salida","Ir Cárcel"}[tipo];
        return aux;
    }

    public String getGrupoString(){
        return grupo.getColor();
    }


    public Boolean isComprable(){ //Suponemos que no se puede comprar una casilla que ya sea de otro jugador
        return tipo < 3 && propietario.isBanca();
    }

    public Boolean getHipotecado(){
        return hipotecado;
    }

    public ArrayList<Jugador> getOcupantes() {
        return ocupantes;
    }

    public int getPosicion() {
        return posicion;
    }

    public static int getLonMaxNombre() {
        return lonMaxNombre;
    }

    public int getTipo() {
        return tipo;
    }

    public Grupo getGrupo() {
        return grupo;
    }

    public Jugador getPropietario() {
        return propietario;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPrecio(){
        return precio;
    }
    public int getvHipoteca(){
        return vHipoteca;
    }

    /**
     * Calcula el alquiler que debe ser pagado al caer en una casilla de tipo solar, transporte, servicio o impuesto
     * @return int con el valor que el jugador que caiga en esa casilla debe pagar.
     */
    public int calcularAlquiler(Dado dado){
        switch (tipo){
            case 0:
                if (grupo.getPropietario()!=null) return 2* alquilerBase;
                else return alquilerBase;
            case 1:
                return propietario.getNTrans()*alquilerBase;
            case 2:
                if (propietario.getNServicios() == 1) return dado.getSuma()*alquilerBase*4;
                else if (propietario.getNServicios() == 2) return dado.getSuma()*alquilerBase*10;
                return 0;
            case 6: return alquilerBase;
            default: return 0; //El los casos especiales, usamos otras funciones
        }
    }


    //toString
    private String StringAvatares(){
        StringBuilder avs = new StringBuilder();
        for (Jugador jugador:ocupantes){
            avs.append("&").append(jugador.getAvatar());
        }
        return avs.toString();
    }

    public String toString (){
        String formato = "|\u001B[4m%"+lonMaxNombre+"s %"+6+"s\u001B[0m|";
        if (grupo!=null) formato = grupo.colorFormato() + formato + "\u001B[0m";
        return String.format(formato,this.nombre,StringAvatares());
    }

    public String descripcion() {
        if (tipo==0) return "{\n" +
                "nombre: " + nombre +"\n"+
                "color: " + grupo.getColor() + "\n"+
                "tipo: "+getTipoString()+" \n" +
                "valor: "+precio+" \n" +
                "}\n";
        else return "{\n" +
                "nombre: " + nombre +"\n"+
                "tipo: "+getTipoString()+" \n" +
                "valor: "+precio+" \n" +
                "}\n";
    }
    public String descripcionDetallada() {
        switch (tipo){
            case 0:
                return "{\n" +
                        "nombre: " + nombre +"\n"+
                        "color: " + grupo.getColor() + "\n"+ //Estaría chulo meterle el formateo para que se vea del color que es
                        "tipo: "+getTipoString()+" \n" +
                        "Propietario: "+propietario.getNombre()+" \n" +
                        "Precio: "+ precio +" \n" +
                        " Alquiler Básico: "+alquilerBase+" \n" +
                        " Alquiler con todo el grupo: "+alquilerBase*2+" \n" +
                        //"Ocupantes: "+ ocupantes +" \n" +

                        "}\n";
            case 1:
                return "{\n" +
                        "nombre: " + nombre +"\n"+
                        "tipo: "+getTipoString()+" \n" +
                        "Propietario: "+propietario.getNombre() +" \n" +
                        "Precio: "+ precio +" \n" +
                        " Alquiler Básico: "+alquilerBase+" \n" +
                        " El alquiler de esta propiedad escala según la cantidad de transportes que tenga el dueño \n" +
                        "}\n";
            case 2:
            return "{\n" +
                        "nombre: " + nombre +"\n"+
                        "tipo: "+getTipoString()+" \n" +
                        "Propietario: "+propietario.getNombre()+" \n" +
                        "Precio: "+ precio +" \n" +
                        " Alquiler Básico: "+alquilerBase+" \n" +
                        " El alquiler de esta propiedad escala según la cantidad de servicios que tenga el dueño \n" +
                        "}\n";
            case 3:
                return "{\n"+
                        "nombre: " + nombre+ "\n"+
                        "descripción: sacas la carta que corresponda al caer en esta casilla.\n" +
                        "}\n";
            case 4:
            case 5:
                return "{\n"+
                        "nombre: " + nombre+
                        "}\n";
            case 6:
                return "{\n"+
                        "nombre: " + nombre+
                        "descripción: al caer en esta casilla, pagas un impuesto a la banca.\n" +
                        "}\n";
            case 7:
                return "{\n"+
                        "nombre: " + nombre+
                        "descripción: al pasar por esta casilla recibes un salario\n" +
                        "}\n";
            case 8:
                return "{\n"+
                        "nombre: " + nombre+
                        "descripción: al caer en esta casilla eres enviado a la cárcel\n" +
                        "}\n";

        }
        return "{\n" +
                "nombre: " + nombre +"\n"+
                "color: " + grupo.getColor() + "\n"+ //Estaría chulo meterle el formateo para que se vea del color que es
                "tipo: "+getTipoString()+" \n" +
                " Alquiler Básico: "+alquilerBase+" \n" +
                " Alquiler con todo el grupo: "+alquilerBase*2+" \n" +
                "valor: "+precio+" \n" +
                "valor: "+precio+" \n" +

                "}\n";
    }

}