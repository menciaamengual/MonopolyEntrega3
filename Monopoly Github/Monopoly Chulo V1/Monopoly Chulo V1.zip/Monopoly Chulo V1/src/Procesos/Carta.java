package Procesos;

public class Carta {
    //Atributos
    private int tipo; //0-1. 0.Suerte 1. Comunidad
    private int posicion;
    private int dinero;
    private boolean carcel;
    private String accion;

}
