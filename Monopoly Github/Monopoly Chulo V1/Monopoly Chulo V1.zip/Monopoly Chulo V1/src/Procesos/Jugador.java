package Procesos;

import java.lang.reflect.Array;
import java.util.*;


public class Jugador {
    //Attributes - PRIVADOS
    private char avatar; //Un caracter que representa al jugador
    private String nombre; //Nombre del jugador
    //    private int tipo; //0-4. Ninguno, Pingüino,submarino, maletín y vaso canopo
    private int posicion;
    private int dinero;
    private ArrayList<Casilla> propiedades;
    private ArrayList<Carta> cartasSuerte;
    private int turnosCarcel; //informa de la situación del jugador respecto de la cárcel:
    // 0: No está en la cárcel / está en la casilla de cárcel pero si tira dados mueve
    // 1: Está en la cárcel, y no tiene oportunidad para salir sacando dobles
    // 2: Está en la cárcel, y tiene UNA oportunidad para tirar dados, sacar dobles y salir
    // 3: Está en la cárcel, y tiene DOS oportunidades para tirar dados, sacar dobles y salir
    // 4: Está en la cárcel, y tiene TRES oportunidades para tirar dados, sacar dobles y salir
    private boolean tiroDadoEnEsteTurno; // Ayuda en la función listar() cuando un jugador está en la cárcel
    private int vueltas;
    private boolean bancarrota;


    //Constructores
    public Jugador(int dinero, String nombre, char avatar) {
        this.dinero = dinero; //inicial: un tercio del valor total de los solares
        this.nombre = nombre;
        this.avatar = avatar; //Generacion del avatar random
        //this.tipo = tipo;
        posicion = 0;
        propiedades = new ArrayList<>(20);
        cartasSuerte = null;
        turnosCarcel = 0;
        tiroDadoEnEsteTurno = false;
        bancarrota = false;
    }

    public Jugador() { //Inicializa la banca
        dinero = 100000000;
        nombre = "Banca";
        avatar = ' ';

        posicion = 0;
        cartasSuerte = null;
        propiedades = new ArrayList<>(40); //Se le meten cuando se crean las propiedades

    }

    //Getters
    public String getNombre() {
        return nombre;
    }

    public ArrayList<Casilla> getPropiedades() {
        return propiedades;
    }

    public ArrayList<Carta> getCartasSuerte() {
        return cartasSuerte;
    }

    public int getDinero() {
        return dinero;
    }

    public int getPosicion() {
        return posicion;
    }

    public int getTurnosCarcel() {
        return turnosCarcel;
    }

    public int getVueltas() {
        return vueltas;
    }

    public char getAvatar() {
        return avatar;
    }

    public int getnCartas() {
        return cartasSuerte.size();
    }

    public Boolean tieneCarta() {
        if (cartasSuerte.isEmpty()) return false;
        else return true;
    }

    public Boolean getBancarrota() {
        return bancarrota;
    }

    public boolean getTiroDadoEnEsteTurno() {
        return tiroDadoEnEsteTurno;
    }

    public Boolean inCarcel() {
        if (this.turnosCarcel != 0) return true;
        else return false;
    }

    public Boolean isBanca() {
        return nombre.equals("Banca");
    }

    /**
     * @param casillas
     * @return
     */
    public Casilla getCasilla(ArrayList<Casilla> casillas) {
        return casillas.get(posicion);
    }

    //Setters

    public void addDinero(int dinero) {
        this.dinero += dinero;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDinero(int dinero) {
        this.dinero = dinero;
    }

    /**
     * Función para pagar alquiler, impuestos... considerando la posibilidad de bancarrota
     *
     * @param alquiler
     */
    public void pagar(int alquiler, Jugador cobrador) {
        while (dinero < alquiler) {
            //Hipotecar hasta que te quedes sin
            if (tienePropiedadesSinHipotecar()) {

            } else {
                cobrador.addDinero(dinero);
                dinero = 0;
                bancarrota = true;
                return;
            }
        }
        dinero -= alquiler;
        cobrador.addDinero(alquiler);
    }

    public boolean tienePropiedadesSinHipotecar() {
        /*boolean aux;
        for (Casilla casilla : propiedades) {
            aux = casilla.getHipotecado();
            if (!aux) return true;
        }
        return false;*/return true;
    }

    public void setPosicion(int posicion, ArrayList<Casilla> casillas) {
        ArrayList<Jugador> aux = new ArrayList<>(6);

        for (Jugador ite:casillas.get(posicion).getOcupantes()){
            if (!equals(ite)) aux.add(ite);
        }
        //casillas.get(posicion).getOcupantes().remove(this);

        //casillas.get(this.posicion).removeOcupante(this)
        casillas.get(this.posicion).setOcupantes(aux);
        this.posicion = posicion;
        casillas.get(posicion).getOcupantes().add(this);
    }

    public void setPropiedades(ArrayList<Casilla> propiedades) {
        this.propiedades = propiedades;
    }

    public void setAvatar(char avatar) {
        this.avatar = avatar;
    }

    public void setBancarrota(boolean bancarrota) {
        this.bancarrota = bancarrota;
    }

    public void setVueltas(int vueltas) {
        this.vueltas = vueltas;
    }

    public void setTurnosCarcel(int turnosCarcel) {
        this.turnosCarcel = turnosCarcel;
    }

    public void setCartasSuerte(ArrayList<Carta> cartasSuerte) {
        this.cartasSuerte = cartasSuerte;
    }

    public void setTiroDadoEnEsteTurno(boolean tiroDadoEnEsteTurno) {
        this.tiroDadoEnEsteTurno = tiroDadoEnEsteTurno;
    }

    //Utilidad
    public void enviarCarcel(ArrayList<Casilla>casillas) {
        turnosCarcel = 4;
        setPosicion(10,casillas);
    }

    /**
     * Añade una propiedad a un jugador, marcandolo también como propietario del grupo en caso de que corresponda
     *
     * @param propiedad
     */
    public void addPropiedad(Casilla propiedad) {
        propiedades.add(propiedad);
        if (propiedad.getTipo() == 0) { //Solo trabajamos con grupos si es un solar
            for (Casilla ite : propiedad.getGrupo().getCasillas()) {
                if (!ite.getPropietario().equals(this) || ite.getPropietario().getNombre().equals("Banca")) return;
            }
            propiedad.getGrupo().setPropietario(this);
        }
    }

    public void removePropiedad(Casilla propiedad) {
        propiedades.remove(propiedad);
    }

    public int getNTrans() {
        int i = 0;
        for (Casilla casilla : propiedades) {
            if (casilla.getTipo() == 1) i++;
        }
        return i;
    }

    public int getNServicios() {
        int i = 0;
        for (Casilla casilla : propiedades) {
            if (casilla.getTipo() == 2) i++;
        }
        return i;
    }


    public boolean equals(Jugador obj) {
        return nombre.equals(obj.getNombre());
    }

    @Override
    public String toString() {
        StringBuilder sProp = new StringBuilder();
        StringBuilder sHip = new StringBuilder();
        for (Casilla prop : propiedades) {
            if (!prop.getHipotecado()) sProp.append(prop.getNombre()).append(" ");
            else sHip.append(prop.getNombre()).append(" ");
        }
        return "{\n" +
                "nombre: " + nombre + ",\n" +
                "avatar: " + avatar + ",\n" +
                "fortuna: " + dinero + ",\n" +
                "propiedades: [" + sProp + "]\n" +
                "hipotecas: [" + sHip + "]\n" +
                //"edificios: [casa-1, casa-2, hotel-4]\n" +
                "}";
    }


}

