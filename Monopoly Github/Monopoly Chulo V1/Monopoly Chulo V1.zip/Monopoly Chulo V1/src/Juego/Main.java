package Juego;// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
//MONOPOLY V1
//Mateito, Cese y Mencía

import java.beans.PersistenceDelegate;
import java.util.Scanner;
import java.util.*;
import Procesos.*;


public class Main {
    public static void main(String[] args) {
        System.out.println("¡--Empieza el juego!--");//Primera aportación de Mencía (que ya son 50 caracteres más que los de Cese)
        //INICIALIZACIÓN
        Juego mono = new Juego();
        Tablero tablero = mono.getTablero();
        //tablero.imprimirTablero();

        //DAR DE ALTA A LOS JUGADORES
        mono.turnoInicial();

        boolean continuar = true;
        while (continuar) {
            continuar = mono.menuAccion(false);
        }

        //FIN DE JUEGO
        System.out.println("Muchas gracias por jugar, ¡hasta la próxima!");
    }
}