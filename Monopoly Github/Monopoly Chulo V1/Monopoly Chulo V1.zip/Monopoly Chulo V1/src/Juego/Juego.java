package Juego;

import java.util.*;
import Procesos.*;

public class Juego {
    //Atributos
    private static Tablero tablero;
    private int dineroInicial;
    private int pSalida; //Premio salida
    private int pBase; //Precio base del juego (precio casilla  primer grupo)
    private Jugador jugadorActual;
    private ArrayList<Jugador> jugadores;

    private Jugador banca;
    private Dado dado;
    private int precioCarcel;

    private StringBuilder avataresrep= new StringBuilder("!");

    private Jugador avatarGetJugador(char avatar){
        for (Jugador jugador:jugadores){
            if (jugador.getAvatar()==avatar) return jugador;
        }
        return null;
    }
    private char generaCharRandom(){
        Random randomc=new Random();
        return (char)(randomc.nextInt(26)+'A');}

    private int contarCharRep(StringBuilder a, char b){
        int c=0;
        for (int i = 0; i < a.length(); i++) {
            if (a.charAt(i) == b) c++;
        }
        return c;}

    //Constructores
    public Juego() {
        jugadores = new ArrayList<Jugador>(6); //La banca se maneja como un jugador externo (banca).
        banca = new Jugador();
        pSalida = Grupo.mediaSolares();
        tablero = new Tablero(pBase, pSalida, banca);
        dado = new Dado();
        dineroInicial = tablero.precioTotal()/3;
        precioCarcel=(int)(pSalida*0.25);
        pBase=100;
    }

    public void darAlta() {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Introduce tu nombre, Jugador " + (jugadores.size() + 1) + " : ");
        String miNombre = entrada.nextLine();
        char miavatar;
        do {
            miavatar = generaCharRandom();
        } while (avataresrep.toString().contains(String.valueOf(miavatar)));
        avataresrep.append(miavatar);

        jugadores.add(new Jugador(dineroInicial, miNombre, miavatar));
    }

    //Getters
    public Tablero getTablero() {
        return tablero;
    }

    //Setters -

    //Ejecución del juego

    /**
     * Este método mueve al jugador y ejecuta las funciones de la casilla de salida
     * NADA más, no llama al siguiente turno, ni al menú, ni nada, eso va fuera
     *
     * @param avance
     */
    public void avanzarCasillas(int avance) {
        if ((jugadorActual.getPosicion() + avance) > 39){
            addVuelta(jugadorActual);
            jugadorActual.setDinero(jugadorActual.getDinero()+pSalida);
            jugadorActual.setPosicion((jugadorActual.getPosicion() + avance)-40, tablero.getCasillas());
        }
        else {
            jugadorActual.setPosicion(jugadorActual.getPosicion()+avance , tablero.getCasillas());
        }
    }

    public void nextJugador() { //Estas dos son public para hacer pruebas, en un programa final, deberían ser privadas
        //Al final de cada turno, avanzamos jugador;
        if (jugadores.indexOf(jugadorActual) == (jugadores.size() - 1))
            jugadorActual = jugadores.get(0);
        else jugadorActual = jugadores.get(jugadores.indexOf(jugadorActual) + 1);
    }


    /**
     * Ejecuta la acción de la casilla. Cobra alquileres, impuestos, etc... y te manda a la carcel si corresponde
     * Y lo avisa por pantalla
     * @param
     */
    public void accionCasilla (){
        int t = jugadorActual.getCasilla(tablero.getCasillas()).getTipo();
        Casilla casilla = jugadorActual.getCasilla(tablero.getCasillas());
        if (t!=4 && t!=7){ //La casilla de carcel, parking gratuido y salida no hacen nada. El "salario" de salida está implementado con el movimiento
            switch (t){
                case 0:
                case 1:
                case 2:
                    if(!casilla.getPropietario().equals(jugadorActual) && !casilla.getPropietario().equals(banca)){ //Si caes en tu misma casilla, no pagas alquiler
                        jugadorActual.pagar(casilla.calcularAlquiler(dado), casilla.getPropietario());
                        System.out.println("Pagas "+casilla.calcularAlquiler(dado)+"$ por caer en "+casilla.getNombre());
                    }
                    break;
                case 3:
                    System.out.println("¡Vaya! Aun no están disponibles las cartas de Suerte y Comunidad.");
                    break;
                case 5: //parking
                    jugadorActual.addDinero(casilla.getAlquilerBase());
                    System.out.println("Has caído en el Parking! cobras "+casilla.getAlquilerBase()+"$.");
                    casilla.setAlquilerBase(0);
                    break;
                case 6: //Impuesto
                    jugadorActual.pagar(casilla.calcularAlquiler(dado),banca);
                    tablero.getCasilla(20).setAlquilerBase(tablero.getCasilla(20).getAlquilerBase()+casilla.calcularAlquiler(dado));
                    System.out.println("Has caído en la casilla impuestos, debes pagar "+casilla.calcularAlquiler(dado));
                    break;
                case 8:
                    jugadorActual.enviarCarcel(tablero.getCasillas());
                    dado.tirarDados(1,2); //Ponemos valores arbitrarios (pero distintos), así NUNCA entras en la cárcel con dobles y se acaba el turno
                    System.out.println("A la cárcel!");
                    break;
            }

        }
    }

    /**
     * Listar copia los condicionales de menuAcción para enseñar al jugador las opciones que tiene disponibles.
     * @param haTirado si el jugadorActual ha tirado ya en este turno
     */
    private void listar(boolean haTirado) {
        System.out.println("----MENU DE AYUDA----");
        System.out.println("  ayuda: imprime esta lista de opciones");
        System.out.println("  jugador: imprime el nombre y avatar del jugador actual");
        System.out.println("  listar jugadores: imprime una lista de los jugadores y sus características");
        if(!haTirado)
            if (jugadorActual.inCarcel()) System.out.println("lanzar dados: lanzar dados para intentar salir de la cárcel");
            else System.out.println("  lanzar dados: lanzar los dados para avanzar");
        if (haTirado){
            System.out.println("  lanzar dados: puedes volver a lanzar los dados si has sacado dados dobles.");
            System.out.println("  acabar turno: finaliza el turno y pasa al siguiente jugador");}
        if (jugadorActual.inCarcel())
            System.out.println("  salir carcel: pagas "+ pSalida/4 +" para salir de la carcel");
        System.out.println("  describir nombreCasilla: imprime una descripción de la casilla indicada" );
        System.out.println("  describir jugador x: imprime una descripción del jugador indicado(x)");
        System.out.println("  describir avatar  x: imprime una descripción del avatar indicado (x)");
        if (haTirado && jugadorActual.getCasilla(tablero.getCasillas()).isComprable())
            System.out.println("  comprar propiedad: si tienes dinero, compra la casilla en la que se encuentra tu avatar");
        System.out.println("  listar en venta: lista las casillas(solares, servicios y transportes) disponibles para comprar");
        System.out.println("  ver tablero: imprime el tablero por pantalla");
        System.out.println("  fin partida: termina el juego");
        }


    /**
     * Función de compra de la casilla, con comprobación de si el jugadorActual tienen suficiente dinero
     * Realiza la transacción correspondiente entre el jugador y la banca, y mueve la propiedad de la Procesos.Casilla, y del grupo en caso de que corresponda
     */
    public void comprarCasilla(){
        Casilla casilla = jugadorActual.getCasilla(tablero.getCasillas());
        if (jugadorActual.getDinero()>=casilla.getPrecio()){
            casilla.getPropietario().addDinero(casilla.getPrecio());
            casilla.setPropietario(jugadorActual);
            jugadorActual.setDinero(jugadorActual.getDinero()-casilla.getPrecio());
        }
        else System.out.println("No tienes dinero suficiente para comprar esta casilla");
    }

    /**
     * Cada vez que se cambia de jugador se llama desde main a menuAcción(false). Después, se hacen llamadas recursivas de menuAcción(false/true, según corresponda) desde el propio menuAccion hasta el fin de turno
     * Llamamos desde la función menuAcción como método para mantener la información de haTirado.
     * Usar recursividad aquí no debería dar problemas pq contamos con que un jugador no haga 20 acciones distintas en su turno
     * @param haTirado
     * @return devuelve un booleano para indicar si sigue la partida o no
     */
    public boolean menuAccion(boolean haTirado) { //Lee y llama a la acción indicada sobre el jugadorActual
        System.out.print("Introduce una acción. Puedes escribir \"ayuda\" para obtener un listado de acciones.\n $>");

        Scanner entrada = new Scanner(System.in);
        String entradaString = entrada.nextLine();
        String[] entradaPartida = entradaString.split(" "); //Esto ya está
        //voy empezando yo, es lo único que queda NTR

        switch (entradaPartida[0]) { //Si no reconoce lo introducido, no llamamos a nada, se llama después del switch
            //case "numero": System.out.println(jugadores.size());break;
            case "ayuda":
                listar(haTirado);

                return menuAccion(haTirado);

            case "jugador":
                System.out.println("Nombre: " + jugadorActual.getNombre());
                System.out.println("Avatar: " + jugadorActual.getAvatar());
                System.out.println("Fortuna: " + jugadorActual.getDinero());
                System.out.println("Posición: " + jugadorActual.getPosicion());
                return menuAccion(haTirado);
            case "listar":
                if (entradaPartida.length>1 && entradaPartida[1].equals("jugadores")) {
                    for(int i = 0; i<jugadores.size(); i++){
                       System.out.println(jugadores.get(i));
                    }
                    return menuAccion(haTirado);
                } else if (entradaPartida.length>2 && entradaPartida[1].equals("en") && entradaPartida[2].equals("venta")) {
                    for (Casilla casilla : tablero.getCasillas()) {
                        if (casilla.isComprable()) System.out.println(" " + casilla.descripcion());
                    }
                    return menuAccion(haTirado);
                } else if (entradaPartida.length>1 && entradaPartida[1].equals("avatares")){

                    for (Jugador ite:jugadores){
                        System.out.println("{\n" +
                                "id: " + ite.getAvatar() + "\n" +
                                "tipo: "+ "N/A" +",\n" +
                                "casilla: "+ ite.getCasilla(tablero.getCasillas()) +"\n" +
                                "jugador: "+ ite.getNombre() +"\n" +
                                "}");
                    }
                    return menuAccion(haTirado);
                }
                break;
            case "comprar":
                if (entradaPartida.length>1 && entradaPartida[1].equals("propiedad") || entradaPartida[1].equals(jugadorActual.getCasilla(tablero.getCasillas()).getNombre())) {
                    if (!haTirado){
                        System.out.println("Debes tirar antes de comprar");
                        break; }
                    else if (!jugadorActual.getCasilla(tablero.getCasillas()).isComprable()){
                        System.out.println("No puedes comprar esta propiedad");
                        break;
                    }
                    else {
                        comprarCasilla();
                        System.out.println("Propiedad comprada con éxito por " + jugadorActual.getCasilla(tablero.getCasillas()).getPrecio() + "$");
                        return menuAccion(true); }
                }
                else { //Si está intentando comprar otra propiedad le avisamos...
                    for (Casilla ite : getTablero().getCasillas()) {
                        if (entradaPartida[1].equals(ite.getNombre())) {
                            System.out.println("Solo puedes comprar la casilla en la que caes...");
                            return menuAccion(haTirado);}
                    }
                    System.out.println("Esta casilla no existe");
                }
                break;
            case "salir":
                if (entradaPartida[1].equals("carcel") || entradaPartida[1].equals("cárcel")) {
                    if (!jugadorActual.inCarcel()) {
                        System.out.println("El jugador actual no está en la carcel...");
                        return menuAccion(haTirado);
                    } else {
                        System.out.println("Pagas " + precioCarcel + " para salir de la cercel.");
                        return menuAccion(true);
                    }
                }
                break;
            case "ver":
                if (entradaPartida[1].equals("tablero")) {
                    tablero.imprimirTablero();
                    return menuAccion(haTirado);
                }
                break;
            case "tirar":
            case "lanzar":
                if (entradaPartida[1].equals("dados")) {
                    if (haTirado && !dado.areEqual()) {
                        System.out.println("Ya no puedes volver a tirar los dados");
                        return menuAccion(true);
                    }
                    if (jugadorActual.inCarcel()) {
                        if (jugadorActual.getTurnosCarcel() == 1) {
                            //En el último turno de carcel, tiene que pagar, y no juega, no puede tirar más veces
                            System.out.println("Ya no puedes tirar más veces los dados :(");
                            return menuAccion(false);
                        }

                        if (jugadorActual.getTurnosCarcel() > 1) {
                            System.out.println("Te quedan" + (jugadorActual.getTurnosCarcel() - 1) + "oportunidades para salir de la cárcel tirando los dados. ¡Adelante!");
                            if (entradaPartida.length==5 && entradaPartida[2].equals("trucados")){
                                dado.tirarDados(Integer.parseInt(entradaPartida[3]),Integer.parseInt(entradaPartida[4]));
                            }
                            else dado.tirarDados();
                            if (dado.areEqual()) {
                                System.out.println("¡Dados dobles! Enhorabuena, sales de la cárcel :)");
                                return menuAccion(true);//t/f
                            } else {
                                System.out.println("Oh no... No has sacado dados dobles. Te quedas en la cárcel.");
                                jugadorActual.setTurnosCarcel(jugadorActual.getTurnosCarcel() - 1);
                                return menuAccion(true);
                            }
                        }
                        break;
                    }
                    else if (!haTirado || dado.areEqual()) {
                        if (entradaPartida.length==5 && entradaPartida[2].equals("trucados")){
                            dado.tirarDados(Integer.parseInt(entradaPartida[3]),Integer.parseInt(entradaPartida[4]));
                        }
                        else dado.tirarDados();
                        System.out.println("Has sacado un " + dado.getDado1() + " y un " + dado.getDado2());
                        if (dado.getC() == 3) {
                            System.out.println("Has sacado dados dobles 3 veces seguidas. ¡Vas a la cárcel! ");
                            jugadorActual.enviarCarcel(tablero.getCasillas());
                            tablero.imprimirTablero();
                            return true;
                        } else if (dado.areEqual()) System.out.println("Has sacado dobles! Puedes volver a tirar.");
                        avanzarCasillas(dado.getSuma());
                        tablero.imprimirTablero();

                        accionCasilla();
                        return menuAccion(true);
                    }
                }
                break;
            case "describir":
            case "descripción":
            case "descripcion":
                if (entradaPartida.length > 1) switch (entradaPartida[1]) {
                    case "jugador":
                    case "Procesos.Jugador":
                        for (Jugador ite : jugadores) {
                            if (entradaPartida.length > 2 && entradaPartida[2].equals(ite.getNombre())) {
                                System.out.print(ite.toString());
                                return menuAccion(haTirado);
                            }
                        }
                        System.out.println("Vaya! No existe este jugador...");
                        break;
                    case "avatar":
                    case "Procesos.Avatar":
                        for (Jugador ite : jugadores) {
                            if (entradaPartida.length > 2 && entradaPartida[2].equals(String.valueOf(ite.getAvatar()))) {
                                System.out.print("{\n" +
                                        "id: " + "A" + ",\n" + //El avatar que corresponda
                                        "tipo: " + "N/A" + ",\n" +
                                        "casilla: " + ite.getCasilla(tablero.getCasillas()).getNombre() + ",\n" +
                                        "jugador: [" + ite.getNombre() + "]\n" +
                                        "}");
                                return menuAccion(haTirado);
                            }
                        }
                        System.out.println("Vaya! No existe este jugador...");
                        break;
                    default:
                        for (Casilla ite : getTablero().getCasillas()) {
                            if (ite.getNombre().equals(entradaPartida[1])) {
                                System.out.print(ite.descripcionDetallada());
                                return menuAccion(haTirado);
                            }
                        }
                        System.out.println("No hay ninguna casilla que se llame así");
                }
            case "fin":
                if (entradaPartida.length > 1 && entradaPartida[1].equals("partida")) return false;
                break;
            case "acabar":
                if (entradaPartida.length > 1 && entradaPartida[1].equals("turno")) {
                    if (!haTirado || dado.areEqual()) System.out.println("Tienes que tirar antes de terminar el turno");
                    else {
                        nextJugador();
                        System.out.println("Turno de: " + jugadorActual.getNombre());
                        return true;
                    }
                    break;
                }
            default:
                System.out.println("No se reconoce la acción... Introduce 'ayuda' para ver tus opciones.");
        }
        return menuAccion(haTirado);
    }

    public void turnoInicial() {
        int cont=0; //para que no se puedan dar de alta mas de 6 jugadores
        //MENSAJE DE BIENVENIDA, Mencía.
        Scanner entrada = new Scanner(System.in);
        System.out.println("Bienvenidos. Empezaremos definiendo los jugadores.");
        String entradaString;

        do{ //J1
            System.out.println("Introduce crear jugador para darte de alta: ");
            entradaString = entrada.nextLine();
        }while(!entradaString.contains("crear jugador"));
        darAlta();
        System.out.println("Primer jugador registrado!");

        //entrada = new Scanner(System.in);
        do{ //J2
            System.out.println("Introduce crear jugador para darte de alta: ");
            entradaString = entrada.nextLine();
        }while(!entradaString.contains("crear jugador"));
        darAlta();
        System.out.println("Segundo jugador registrado!");

        do{
            do{ //Jx
                System.out.println("Ahora puedes introducir 'crear jugador' para darte de alta o 'empezar juego' para comenzar a jugar: ");
                entradaString = entrada.nextLine();
            }while(!entradaString.contains("crear jugador") && !entradaString.contains("empezar juego"));

            if(entradaString.contains("crear jugador")){
                darAlta();
                cont++;
                System.out.println("Jugador registrado!");
            }

        }while(!entradaString.contains("empezar juego") && cont<4);
        if (cont == 4) System.out.println("No se pueden agregar más jugadores");
        System.out.println("Jugadores registrados!");

        jugadorActual = jugadores.get(0);

        tablero.getCasilla(0).setOcupantes(jugadores);
    }

    public void addVuelta(Jugador jugador) {
        jugador.setVueltas(jugador.getVueltas() + 1);
        for (Jugador ite:jugadores){ //Comprobamos que sea el jugador que va de último
            if (jugador.getVueltas()>ite.getVueltas()) return;
        }
        if (jugador.getVueltas()%4 == 0 && jugador.getVueltas()!=0) //Y que comienza una vuelta múltiplo de 4
            actualizarCasillas();
    }
    private void actualizarCasillas() {
        for (Casilla ite: getTablero().getCasillas())
            if(ite.getPropietario().isBanca()){
              ite.setPrecio((int) (ite.getPrecio()*1.05));
        }
    }
}

